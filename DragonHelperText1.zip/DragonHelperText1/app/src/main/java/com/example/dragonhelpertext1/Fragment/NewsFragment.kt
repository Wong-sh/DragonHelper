package com.example.dragonhelpertext1.Fragment

class NewsFragment {
}