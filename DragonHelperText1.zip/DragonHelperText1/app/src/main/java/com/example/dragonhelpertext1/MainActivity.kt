package com.example.dragonhelpertext1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.view.ViewPager
import android.widget.Toast
import com.example.dragonhelpertext1.Adapter.MainTabLayoutAdapter
import com.example.dragonhelpertext1.Fragment.NewsFragment
import com.example.dragonhelpertext1.Fragment.SettingFragment

class MainActivity : AppCompatActivity(), ViewPager.onPageChangeListener {

    private lateinit var tabLayout: TabLayout
    private lateinit var viewPager: ViewPager
    private var titleList = ArrayList<String>()
    private var fragmentList = ArrayList<android.support.v4.app.Fragment> ()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //定义控件
        findView()
        //定义viewPager,并与tabLayout关联
        resetViewPager()
        //为viewPager添加内容
        putValue()

    }

    private fun findView(){

        viewPager = findViewById(R.id.main_viewpager)
        tabLayout = findViewById(R.id.main_tabLayout)
    }

    private fun resetViewPager(){

        viewPager.adapter = MainTabLayoutAdapter(supportFragmentManager, fragmentList, titleList)
        tabLayout.setupWithViewPager(viewPager)
    }

    private fun putValue(){

        viewPager.addOnAdapterChangeListener(this)
        val fragmentNews by lazy {NewsFragment()}
        val fragmentSetting by lazy {SettingFragment()}
        fragmentList.add(fragmentNews)
        fragmentList.add(fragmentSetting)
        titleList.add("新消息")
        titleList.add("设置")
    }

    override fun onPageScrollStateChanged(p0: Int) {
    }

    override fun onPageScrolled(p0: Int, p1: Float, p2: Int) {
        Toast.makeText(this, "这是第${p0+1}个界面", Toast.LENGTH_SHORT).show()
    }

    override fun onPageSelected(p0: Int) {
        Toast.makeText(this, "这是第${p0+1}个界面", Toast.LENGTH_SHORT).show()
    }

}